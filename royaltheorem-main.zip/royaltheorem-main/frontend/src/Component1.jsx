import React from 'react'
import './Component1.css'
export default function Component1() {
  return (
    <div>
    <div class="cards">
    <div class="card">
        <svg height="200px" width="200px">

            <text class="r" x="40" y="170" fill="red">R</text>
            <text class="t" x="50" y="175" >T</text>
        </svg>
    </div>
    <div class="card">
        <svg height="200px" width="200px">

            <text class="r" x="40" y="170" fill="red">R</text>
            <text class="t" x="50" y="175" >T</text>
        </svg>
    </div>
    <div class="card">
        <svg height="200px" width="200px">

            <text class="r" x="40" y="170" fill="red">R</text>
            <text class="t" x="50" y="175" >T</text>
        </svg>
    </div>
    <div class="card">
        <svg height="200px" width="200px">

            <text class="r" x="40" y="170" fill="red">R</text>
            <text class="t" x="50" y="175" >T</text>
        </svg>
    </div>
    <div class="card">
        <svg height="200px" width="200px">

            <text class="r" x="40" y="170" fill="red">R</text>
            <text class="t" x="50" y="175" >T</text>
        </svg>
    </div>
    
</div>
</div>
  )
}
