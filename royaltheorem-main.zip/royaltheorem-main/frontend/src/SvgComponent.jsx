import React from 'react'
import './svgComponent.css';
export default function SvgComponent() {
  return (
    <div class="mainsvg">
    <div class="svg">
    <svg height="200px" width="200px">

        <text class="r" x="40" y="170" fill="red">R</text>
        <text class="t" x="50" y="175" >T</text>
    </svg>
</div>
<div class="svg1">
    <div><h1>HENCE</h1></div>
    <div><h2>PROVED</h2></div>
</div>
</div>

  )
}
