import React from 'react'
import './Component2.css'
export default function Component2() {
  return (
    <div class="third">
        <h1>ROYALITY IS NOW PROVEN</h1>
    </div>
  )
}
