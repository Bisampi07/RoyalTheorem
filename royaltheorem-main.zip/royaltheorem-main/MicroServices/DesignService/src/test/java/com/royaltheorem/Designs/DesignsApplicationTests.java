package com.royaltheorem.Designs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesignsApplicationTests {

	@Test
	void contextLoads() {
	}

}
