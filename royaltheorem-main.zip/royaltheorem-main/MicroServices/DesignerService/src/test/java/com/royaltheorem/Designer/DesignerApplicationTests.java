package com.royaltheorem.Designer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesignerApplicationTests {

	@Test
	void contextLoads() {
	}

}
